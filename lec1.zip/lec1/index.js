function sum(a,b)
{
    return a+b;
}
function sub(a,b)
{
    return a-b;
}
sum(3,4);
sum(6,5);